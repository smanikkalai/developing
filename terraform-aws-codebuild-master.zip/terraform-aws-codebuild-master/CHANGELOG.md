## 0.6.0 (July 1, 2021)

ENHANCEMENTS:

* Add support to use existing service role ARN (thanks @sebbrandt87)

## 0.5.3 (April 22, 2021)

ENHANCEMENTS:

* Add pre-commit config file
* Add .gitignore file
* Update README

FIXES:

  * Update examples

## 0.5.2 (March 18, 2021)

FIXES:

  * Update examples

## 0.5.1 (March 18, 2021)

ENHANCEMENTS:

  * Update examples & README

## 0.5.0 (March 18, 2021)

FEATURES:

  * Add secondary sources (based on @brettminnie's)
  * Update example with secondary sources

## 0.4.0 (March 17, 2021)

FEATURES:

  * Add secondary sources (thanks @brettminnie)


## 0.3.0 (Feb 24, 2021)

FEATURES:

  * Added type lookup to environment variables

Thanks @brettminnie

## 0.2.1 (May 28, 2020)

FIXES:

  * Change default values for sourcea block

## 0.2.0 (May 28, 2020)

FIXES:

  * Change default artifacts type to `CODEPIPELINE`

## 0.1.1 (April 17, 2020)

UPDATES:

  * Fix typos in README

## 0.1.0 (April 17, 2020)

FEATURES:

  * Module implementation
